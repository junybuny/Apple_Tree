package com.guestbook.db;

import java.sql.*;
import java.util.*;

public class GuestbookDao {

    // DB에 접속하여 Connection 객체를 반환
    private Connection getConnection() throws Exception {

        Class.forName("org.mariadb.jdbc.Driver");
        Connection conn = DriverManager.getConnection(
                    "jdbc:mariadb://localhost:3306/jspdb", "jsp", "1234");

        return conn;
    }

    // 게시글 리스트 읽기
    public ArrayList<GuestbookDto> selectList() {

        ArrayList<GuestbookDto> dtoList = new ArrayList<GuestbookDto>();

        try (
            Connection conn = getConnection();
            Statement stmt = conn.createStatement();

            ResultSet rs = stmt.executeQuery(String.format(
                    "select * from guestbook"));
        ) {
            while (rs.next()) {

                // 새 DTO 객체를 만들고 글 데이터를 이 객체에 저장
                GuestbookDto dto = new GuestbookDto();

                dto.setNum    (rs.getInt   ("num"    ));
                dto.setContent(rs.getString("content"));
                dto.setContent2(rs.getString("content2"));
                dto.setContent3(rs.getString("content3"));
                dto.setContent4(rs.getString("content4"));
                dto.setContent5(rs.getString("content5"));

                // 이 DTO 객체를 ArrayList에 추가
                dtoList.add(dto);
            }
        } catch(Exception e) {
            e.printStackTrace();
        }

        return dtoList;
    }

    // 지정된 글 번호를 가진 레코드 읽기
    public GuestbookDto selectOne(int num) {

    	GuestbookDto dto = new GuestbookDto();

        try (
            Connection conn = getConnection();
            Statement stmt = conn.createStatement();

            ResultSet rs = stmt.executeQuery(
                    "select * from guestbook where num=" + num);
        ) {
            if (rs.next()) {

                // 글 데이터를 DTO에 저장
                dto.setNum    (rs.getInt   ("num"    ));
                dto.setContent(rs.getString("content"));
                
            }
        } catch(Exception e) {
            e.printStackTrace();
        }

        return dto;
    }

    // DTO에 담긴 내용으로 새로운 레코드 저장
    public void insertOne(GuestbookDto dto) {

        try (
            Connection conn = getConnection();
            Statement stmt = conn.createStatement();
        ) {
            stmt.executeUpdate(String.format(
                    "insert into guestbook " +
                    "(content)" +
                    "values ('%s')",
                    dto.getContent()));

        } catch(Exception e) {
            e.printStackTrace();
        }
    }


    // 지정된 글 번호의 레코드 삭제
    public void deleteOne(int num) {

        try (
            Connection conn = getConnection();
            Statement stmt = conn.createStatement();
        ) {
            stmt.executeUpdate("delete from guestbook where num=" + num);

        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}