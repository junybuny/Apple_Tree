package com.login.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.board.service.boardService;
import com.board.vo.boardVo;
import com.controller.Controller;
import com.controller.HttpUtil;
import com.login.service.loginService;
import com.member.vo.memberVo;

public class myPageController implements Controller {
	
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {

		// 똑같이 적기
		HttpSession session = request.getSession();
		// 똑같이 적기
		request.setCharacterEncoding("UTF-8");
		String member_id = (String)session.getAttribute("session_id");
		
		// 위에서 받아온값을 다시 board 데이터에 세팅하기
		memberVo member = new memberVo();
		member.setMember_id(member_id);
		
		
		// Service 객체의 메소드 호출
		// 똑같이 적기
		loginService service = loginService.getInstance();
		
		memberVo myPage = service.myPage(member);
		System.out.println();
		System.out.println("@@@@@@@"+myPage.getMember_address());
		

		// 여기는 데이터 형식 확인, boolean -> true,false / int 정수 / String 텍스트
		// 서비스에 있는 함수의 리턴값 받아오기
				
		request.setAttribute("myPage",myPage);
		HttpUtil.forward(request, response, "jsp/login/myPage.jsp");
			
		
		
		
		
		
	
	}
}